#!/usr/bin/env bash
# 用法: ./check_symbols.sh libhml.so

set -e

if [ $# -ne 1 ]; then
  echo "用法: $0 <path_to_so>"
  exit 1
fi

sofile=$1

if [ ! -f "$sofile" ]; then
  echo "错误: 文件 $sofile 不存在"
  exit 1
fi

# 符号列表（从 MKLML_ROUTINE_EACH 中提取）
symbols=(
cblas_sgemm cblas_dgemm cblas_cgemm cblas_zgemm
cblas_saxpy cblas_daxpy cblas_caxpy cblas_zaxpy
cblas_scopy cblas_dcopy cblas_ccopy cblas_zcopy
cblas_sgemv cblas_dgemv cblas_cgemv cblas_zgemv
cblas_strsm cblas_dtrsm cblas_ctrsm cblas_ztrsm
cblas_sgemm_alloc cblas_dgemm_alloc
cblas_sgemm_pack cblas_dgemm_pack
cblas_sgemm_compute cblas_dgemm_compute
cblas_sgemm_free cblas_dgemm_free
cblas_sgemm_batch cblas_dgemm_batch cblas_cgemm_batch cblas_zgemm_batch
cblas_sdot cblas_ddot cblas_sasum cblas_dasum
cblas_isamax cblas_idamax cblas_sscal cblas_dscal
vsAdd vdAdd vsSub vdSub vsMul vdMul vsDiv vdDiv
vsExp vdExp vsSqr vdSqr vsPowx vdPowx vsInv vdInv
vmsErf vmdErf MKL_Free_Buffers MKL_Set_Num_Threads MKL_Get_Max_Threads
)

echo "检查共享库: $sofile"
echo "---------------------------------------"

# 从目标 so 文件提取符号表
nm_output=$(nm -D --defined-only "$sofile" 2>/dev/null || objdump -T "$sofile" 2>/dev/null)

if [ -z "$nm_output" ]; then
  echo "警告: 无法解析符号，尝试使用 objdump"
  nm_output=$(objdump -T "$sofile" 2>/dev/null)
fi

missing=()
for sym in "${symbols[@]}"; do
  if ! echo "$nm_output" | grep -q "$sym"; then
    missing+=("$sym")
  fi
done

if [ ${#missing[@]} -eq 0 ]; then
  echo "✅ 所有符号均存在于 $sofile 中"
else
  echo "❌ 缺少以下符号:"
  for s in "${missing[@]}"; do
    echo "  - $s"
  done
fi

