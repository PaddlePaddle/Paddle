/* * Copyright (c) 2014, 2015                                          Zhang Xianyi
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef _HYGONVML_COMMON_H_
#define _HYGONVML_COMMON_H_

#include "hygonvml_config.h"

/* =------------------------------------= */
/*     VML_COMPLEX8 & VML_COMPLEX16       */
/* =------------------------------------= */
/** HygonVML Complex type for single precision
 * Note that VML_Complex8 could be overwitten by -DVML_COMPLEX8="...".
 */
#ifndef VML_COMPLEX8
typedef
struct _VML_COMPLEX8 {
    float real;
    float imag;
} VML_COMPLEX8;
#endif

/** HygonVML Complex type for double precision
 * Note that VML_COMPLEX16 could be overwitten by -DVML_COMPLEX16="...".
 */
#ifndef VML_COMPLEX16
typedef
struct _VML_COMPLEX16 {
    double real;
    double imag;
} VML_COMPLEX16;
#endif

/* =-------------------------------------------= */
/*     VML_CMPLX_UNION16 & VML_CMPLX_UNION8      */
/* =-------------------------------------------= */
/** @attention: This union type definition assumes that Complex
 * number's real part and imaginary part are stored consecutively in
 * memory.
 */
#if !defined(__STDC_NO_COMPLEX__)
typedef
union {
  double _Complex c;
  VML_COMPLEX16 t;
} VML_CMPLX_UNION16;

typedef
union {
  float _Complex c;
  VML_COMPLEX8 t;
} VML_CMPLX_UNION8;
#endif

/* =---------------------------------------------= */
/*     VML_FLOAT & VML_COMPLEX & VML_CMPLX_UNION   */
/* =---------------------------------------------= */
#ifdef DOUBLE
typedef double            VML_FLOAT;
typedef VML_COMPLEX16     VML_COMPLEX;
typedef VML_CMPLX_UNION16 VML_CMPLX_UNION;
#else /* DOUBLE */
typedef float             VML_FLOAT;
typedef VML_COMPLEX8      VML_COMPLEX;
typedef VML_CMPLX_UNION8  VML_CMPLX_UNION;
#endif /* FLOAT */

#if defined(OS_WINDOWS) && defined(__64BIT__)
typedef long long VMLLONG;
typedef unsigned long long VMLULONG;
#else
typedef long VMLLONG;
typedef unsigned long VMLULONG;
#endif

#ifdef USE64BITINT
typedef VMLLONG VML_INT;
#else
typedef int VML_INT;
#endif

// These macros in the comments below are previously used
//#define HygonVML_FUNCNAME_3(pre,x,suf) pre##x##suf
//#define HygonVML_FUNCNAME_2(pre,x,suf) HygonVML_FUNCNAME_3(pre, x, suf)
//#define HygonVML_FUNCNAME_1(x) HygonVML_FUNCNAME_2(HYGONVML_FUNC_PREFIX, x, HYGONVML_FUNC_SUFFIX)
//#define HygonVML_FUNCNAME(x) HygonVML_FUNCNAME_1(x)

#define HygonVML_FUNCNAME(x) x

#if defined(__REPLACE_LMVEC_SVML__)
/* ............................ LMVEC KERNEL .............................. */
#define _ZGVbN2v_pow _ZGVbN2vv_pow
#define _ZGVdN4v_pow _ZGVdN4vv_pow
#define _ZGVbN4v_powf _ZGVbN4vv_powf
#define _ZGVdN8v_powf _ZGVdN8vv_powf
#define _ZGVbN2v_atan2 _ZGVbN2vv_atan2
#define _ZGVdN4v_atan2 _ZGVdN4vv_atan2
#define _ZGVbN4v_atan2f _ZGVbN4vv_atan2f
#define _ZGVdN8v_atan2f _ZGVdN8vv_atan2f
#define _ZGVbN2v_hypot _ZGVbN2vv_hypot
#define _ZGVdN4v_hypot _ZGVdN4vv_hypot
#define _ZGVbN4v_hypotf _ZGVbN4vv_hypotf
#define _ZGVdN8v_hypotf _ZGVdN8vv_hypotf
#define _ZGVbN2v_ln _ZGVbN2v_log
#define _ZGVdN4v_ln _ZGVdN4v_log
#define _ZGVbN4v_lnf _ZGVbN4v_logf
#define _ZGVdN8v_lnf _ZGVdN8v_logf
#define LMVEC_KERNEL_d2(name) _ZGVbN2v_##name
#define LMVEC_KERNEL_d4(name) _ZGVdN4v_##name
#define LMVEC_KERNEL_s4(name) _ZGVbN4v_##name##f
#define LMVEC_KERNEL_s8(name) _ZGVdN8v_##name##f
#define LMVEC_FUNCNAME(name, vf, prec) LMVEC_KERNEL_##prec##vf(name)

/* ............................ SVML KERNEL .............................. */
#define __svml_ln2 __svml_log2
#define __svml_ln4 __svml_log4
#define __svml_lnf4 __svml_logf4
#define __svml_lnf8 __svml_logf8
#define __svml_sinCos2 __svml_sincos2
#define __svml_sincCos4 __svml_sincos4
#define __svml_sinCosf4 __svml_sincosf4
#define __svml_sincosf8 __svml_sincosf8
#define __svml_sqrt_mask2 __svml_sqrt2_mask
#define __svml_sqrt_mask4 __svml_sqrt4_mask
#define __svml_sqrt_maskf4 __svml_sqrtf4_mask
#define __svml_sqrt_maskf8 __svml_sqrtf8_mask
#define SVML_KERNEL_d2(name) __svml_##name##2
#define SVML_KERNEL_d4(name) __svml_##name##4_l9  // l9 stands for AVX2
#define SVML_KERNEL_s4(name) __svml_##name##f4
#define SVML_KERNEL_s8(name) __svml_##name##f8_l9 // l9 stands for AVX2
#define SVML_FUNCNAME(name, vf, prec) SVML_KERNEL_##prec##vf(name)

#endif

#endif
