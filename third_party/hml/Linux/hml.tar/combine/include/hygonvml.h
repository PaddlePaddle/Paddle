/* * Copyright (c) 2014, 2015                                          Zhang Xianyi
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef _HYGONVML_H_
#define _HYGONVML_H_

#include "hygonvml_export.h"
#include "hygonvml_common.h"

#ifdef __cplusplus
extern "C" {
#endif

HYGONVML_EXPORT char* HygonVML_FUNCNAME(hygonvml_get_config)();
HYGONVML_EXPORT char* vml_get_cpu_arch();

/* - - - - - - - - - - - - - - - - - Arithmetic Routines - - - - - - - - - - - - - - - - - - - */
HYGONVML_EXPORT void HygonVML_FUNCNAME(vsAdd)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdAdd)(const VML_INT n, const double * a, const double * b, double * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vcAdd)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vzAdd)(const VML_INT n, const double * a, const double * b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsSub)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdSub)(const VML_INT n, const double * a, const double * b, double * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vcSub)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vzSub)(const VML_INT n, const double * a, const double * b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsSqr)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdSqr)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsMul)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdMul)(const VML_INT n, const double * a, const double * b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsFmod)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdFmod)(const VML_INT n, const double * a, const double * b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsRemainder)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdRemainder)(const VML_INT n, const double * a, const double * b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsAbs)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdAbs)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsDiv)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdDiv)(const VML_INT n, const double * a, const double * b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsLinearFrac)(const VML_INT n, const float * a, const float * b, const float scalea, const float shifta, const float scaleb, const float shiftb, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdLinearFrac)(const VML_INT n, const double * a, const double * b, const double scalea, const double shifta, const double scaleb, const double shiftb, double * y);

/* - - - - - - - - - - - - - - - Complex Arithmetic Routines - - - - - - - - - - - - - - - - - - - */
HYGONVML_EXPORT void HygonVML_FUNCNAME(vcConj)(const VML_INT n, const VML_COMPLEX8 * a, VML_COMPLEX8 * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vzConj)(const VML_INT n, const VML_COMPLEX16 * a, VML_COMPLEX16 * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vcArg)(const VML_INT n, const VML_COMPLEX8 * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vzArg)(const VML_INT n, const VML_COMPLEX16 * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vcCIS)(const VML_INT n, const float * a, VML_COMPLEX8 * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vzCIS)(const VML_INT n, const double * a, VML_COMPLEX16 * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vcMulByConj)(const VML_INT n, const VML_COMPLEX8 * a, const VML_COMPLEX8 * b, VML_COMPLEX8 * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vzMulByConj)(const VML_INT n, const VML_COMPLEX16 * a, const VML_COMPLEX16 * b, VML_COMPLEX16 * y);

/* - - - - - - - - - - - - - - - - - Power & Root Routines - - - - - - - - - - - - - - - - - - - */
HYGONVML_EXPORT void HygonVML_FUNCNAME(vsInv)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdInv)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsSqrt)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdSqrt)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsInvSqrt)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdInvSqrt)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsCbrt)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdCbrt)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsInvCbrt)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdInvCbrt)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsPow2o3)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdPow2o3)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsPow3o2)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdPow3o2)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsPow)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdPow)(const VML_INT n, const double * a, const double * b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsPowx)(const VML_INT n, const float * a, const float b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdPowx)(const VML_INT n, const double * a, const double b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsPowr)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdPowr)(const VML_INT n, const double * a, const double * b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsHypot)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdHypot)(const VML_INT n, const double * a, const double * b, double * y);

/* - - - - - - - - - - - - - - - - - Exp & Log Routines - - - - - - - - - - - - - - - - - - - */
HYGONVML_EXPORT void HygonVML_FUNCNAME(vsExp)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdExp)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsExp2)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdExp2)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsExp10)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdExp10)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsExpm1)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdExpm1)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsLn)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdLn)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsLog2)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdLog2)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsLog10)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdLog10)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsLog1p)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdLog1p)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsLogb)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdLogb)(const VML_INT n, const double * a, double * y);


/* - - - - - - - - - - - - - - - - - Trigonometric Routines - - - - - - - - - - - - - - - - - - - */
HYGONVML_EXPORT void HygonVML_FUNCNAME(vsCos)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdCos)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsCospi)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdCospi)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsTanpi)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdTanpi)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsTand)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdTand)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsSind)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdSind)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsCosd)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdCosd)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsAcospi)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdAcospi)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsAsinpi)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdAsinpi)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsAtanpi)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdAtanpi)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsSinpi)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdSinpi)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsSin)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdSin)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsSinCos)(const VML_INT n, const float * a, float * y, float * z);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdSinCos)(const VML_INT n, const double * a, double * y, double * z);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsTan)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdTan)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsAcos)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdAcos)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsAsin)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdAsin)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsAtan)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdAtan)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsAtan2)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdAtan2)(const VML_INT n, const double * a, const double * b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsAtan2pi)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdAtan2pi)(const VML_INT n, const double * a, const double * b, double * y);

/* - - - - - - - - - - - - - - - - - Hyperbolic Routines - - - - - - - - - - - - - - - - - - - */
HYGONVML_EXPORT void HygonVML_FUNCNAME(vsCosh)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdCosh)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsSinh)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdSinh)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsTanh)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdTanh)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsAcosh)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdAcosh)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsAsinh)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdAsinh)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsAtanh)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdAtanh)(const VML_INT n, const double * a, double * y);

/* - - - - - - - - - - - - - - - - - Special Routines - - - - - - - - - - - - - - - - - - - */
HYGONVML_EXPORT void HygonVML_FUNCNAME(vsErf)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdErf)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsErfc)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdErfc)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsCdfNorm)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdCdfNorm)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsErfInv)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdErfInv)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsErfcInv)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdErfcInv)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsCdfNormInv)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdCdfNormInv)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsExpInt1)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdExpInt1)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsTGamma)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdTGamma)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsLGamma)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdLGamma)(const VML_INT n, const double * a, double * y);

/* - - - - - - - - - - - - - - - - - Rounding Routines - - - - - - - - - - - - - - - - - - - */
HYGONVML_EXPORT void HygonVML_FUNCNAME(vsFloor)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdFloor)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsRound)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdRound)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsCeil)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdCeil)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsTrunc)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdTrunc)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsRint)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdRint)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsNearbyInt)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdNearbyInt)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsModf)(const VML_INT n, const float * a, float * y, float * z);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdModf)(const VML_INT n, const double * a, double * y, double * z);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsFrac)(const VML_INT n, const float * a, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdFrac)(const VML_INT n, const double * a, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsFdim)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdFdim)(const VML_INT n, const double * a, const double * b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsFmax)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdFmax)(const VML_INT n, const double * a, const double * b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsFmin)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdFmin)(const VML_INT n, const double * a, const double * b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsMaxMag)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdMaxMag)(const VML_INT n, const double * a, const double * b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsMinMag)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdMinMag)(const VML_INT n, const double * a, const double * b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsCopySign)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdCopySign)(const VML_INT n, const double * a, const double * b, double * y);

HYGONVML_EXPORT void HygonVML_FUNCNAME(vsNextAfter)(const VML_INT n, const float * a, const float * b, float * y);
HYGONVML_EXPORT void HygonVML_FUNCNAME(vdNextAfter)(const VML_INT n, const double * a, const double * b, double * y);

#ifdef __cplusplus
}
#endif
#endif
