#ifndef _HML_H_
#define _HML_H_

#include "blis.h"
#include "cblas.h"
#include "hygonvml.h"
#include "hygonvml_common.h"
#include "hygonvml_config.h"
#include "hygonvml_export.h"

#endif
